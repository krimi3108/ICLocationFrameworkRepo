//
//  ICLocationFramework.h
//  ICLocationFramework
//
//  Created by Kritika on 15/11/18.
//  Copyright © 2018 ranosys. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ICLocationFramework.
FOUNDATION_EXPORT double ICLocationFrameworkVersionNumber;

//! Project version string for ICLocationFramework.
FOUNDATION_EXPORT const unsigned char ICLocationFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ICLocationFramework/PublicHeader.h>


