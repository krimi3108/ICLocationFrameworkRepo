//
//  ICLoctionFramework.h
//  ICLoctionFramework
//
//  Created by Kritika on 15/11/18.
//  Copyright © 2018 ranosys. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ICLoctionFramework.
FOUNDATION_EXPORT double ICLoctionFrameworkVersionNumber;

//! Project version string for ICLoctionFramework.
FOUNDATION_EXPORT const unsigned char ICLoctionFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ICLoctionFramework/PublicHeader.h>


